"""
neaps_sparse.py
===============
Thread-safe incremental BM25 inverted index persisted locally to a .pkl file.

Concurrency model (production-safe):
  - ONE dedicated writer thread consumes a queue.Queue — zero concurrent writes.
  - Readers acquire threading.RLock for the dirty-flag check + iteration.
  - add_chunks() is fully non-blocking (enqueue-and-return).
  - flush() blocks until all queued writes are applied and the index is saved.
"""

import logging
import math
import pickle
import queue
import re
import threading
import time
import array
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

_INDEX_DIR  = Path(__file__).resolve().parent.parent / "indexes"
_INDEX_FILE = _INDEX_DIR / "neaps_bm25_index.pkl"

# Financial-domain stopwords
_STOPWORDS = frozenset({
    "a", "an", "the", "and", "or", "of", "to", "in", "for", "on",
    "at", "by", "is", "are", "was", "were", "be", "been", "being",
    "with", "as", "from", "that", "this", "it", "its", "has", "have",
    "had", "not", "but", "if", "so", "do", "does", "did", "will",
    "would", "shall", "should", "may", "might", "can", "could",
    "about", "into", "than", "all", "any", "no", "such", "also",
    "per", "re", "via", "ie", "eg",
})


def _tokenize(text: str) -> List[str]:
    """Lowercase, strip punctuation, split on whitespace, remove stopwords."""
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    return [t for t in text.split() if len(t) > 1 and t not in _STOPWORDS]


class LocalIncrementalBM25:
    """
    Incremental BM25 index with production-safe concurrency.

    Writer contract:
      - Only _writer_loop() mutates inverted_index / df / documents / N / total_dl.
      - All other code treats those as read-only while holding _rlock.

    Reader contract:
      - search() acquires _rlock to guard against dict size changes during iteration.
      - _rlock is re-entrant so helpers called from search() are safe.
    """

    def __init__(self, k1: float = 1.5, b: float = 0.75):
        self.k1 = k1
        self.b  = b
        self.N       = 0
        self.total_dl = 0

        self.df:             Dict[str, int]              = {}
        self.idf:            Dict[str, float]            = {}
        self.inverted_index: Dict[str, array.array] = {}
        self.documents:      List[Dict[str, Any]]        = []

        # Concurrency primitives
        self._rlock     = threading.RLock()   # readers + dirty-flag guard
        self._idf_dirty = False
        self._write_q   = queue.Queue()       # single-writer queue

        # Single dedicated writer thread
        self._writer = threading.Thread(
            target  = self._writer_loop,
            name    = "bm25-writer",
            daemon  = True,
        )
        self._writer.start()
        logger.debug("[BM25] Single-writer thread started.")

    # ------------------------------------------------------------------
    # Public API — callable from any thread
    # ------------------------------------------------------------------

    def add_chunks(self, chunks: List[Dict[str, Any]], save: bool = True) -> None:
        """
        Non-blocking enqueue.  Returns immediately; actual mutation happens in
        the dedicated writer thread.

        Args:
            chunks: List of chunk dicts with 'text' and 'metadata'.
            save:   If True (default), persists to disk after applying this batch.
        """
        if not chunks:
            return
        self._write_q.put(("add", chunks, save))

    def flush(self, timeout: float = 60.0) -> bool:
        """
        Block until all pending writes are applied and the index is saved to disk.
        Returns True if flushed successfully, False if timed out.
        """
        done_event = threading.Event()
        self._write_q.put(("flush", done_event))
        finished = done_event.wait(timeout=timeout)
        if not finished:
            logger.warning(f"[BM25] flush() timed out after {timeout}s")
        return finished

    def search(
        self,
        query:          str,
        company_symbol: Optional[str] = None,
        top_k:          int = 20,
    ) -> List[Dict[str, Any]]:
        """Thread-safe search — acquires _rlock to guard index iteration."""
        t0 = time.perf_counter()
        with self._rlock:
            if self._idf_dirty:
                self._recompute_idf()
                self._idf_dirty = False

            if self.N == 0:
                return []

            results = self._search_internal(query, company_symbol, top_k)

        elapsed_ms = (time.perf_counter() - t0) * 1000
        logger.debug(f"[BM25] search returned {len(results)} results in {elapsed_ms:.1f}ms")
        return results

    def save(self, path: Path = None) -> None:
        """
        Persist index to disk safely (atomic tmp → replace).
        Call flush() first if you need guaranteed write-consistency.
        """
        path = path or _INDEX_FILE
        with self._rlock:
            if self._idf_dirty:
                self._recompute_idf()
                self._idf_dirty = False
            data = {
                "documents":      list(self.documents),
                "inverted_index": dict(self.inverted_index),
                "df":       dict(self.df),
                "idf":      dict(self.idf),
                "N":        self.N,
                "total_dl": self.total_dl,
                "k1":       self.k1,
                "b":        self.b,
            }
        self._write_to_disk(data, path)

    def load(self, path: Path = None) -> bool:
        """Load index from disk (called at startup, before writer thread is busy)."""
        path = path or _INDEX_FILE
        if not path.exists():
            return False
        try:
            with open(path, "rb") as f:
                data = pickle.load(f)
            # Direct assignment — safe here because we're in __init__ / load,
            # no concurrent writers yet.
            
            migrated = False
            docs = data["documents"]
            if docs and "text" in docs[0]:
                logger.info("[BM25] Migrating legacy documents list to lightweight format...")
                new_docs = []
                for d in docs:
                    meta = d.get("metadata", {})
                    new_docs.append({
                        "id": d["id"],
                        "length": d["length"],
                        "company_symbol": meta.get("company_symbol", ""),
                        "active": meta.get("active", True),
                    })
                self.documents = new_docs
                migrated = True
            else:
                self.documents = docs

            inv_idx = data["inverted_index"]
            if inv_idx and isinstance(next(iter(inv_idx.values())), list):
                logger.info("[BM25] Migrating legacy inverted_index to array.array format...")
                new_idx = {}
                for token, postings in inv_idx.items():
                    arr = array.array('I')
                    for doc_idx, count in postings:
                        arr.append(doc_idx)
                        arr.append(count)
                    new_idx[token] = arr
                self.inverted_index = new_idx
                migrated = True
            else:
                self.inverted_index = inv_idx

            if migrated:
                logger.info("[BM25] Migration complete. Memory footprint reduced.")
            self.df             = data["df"]
            self.idf            = data["idf"]
            self.N              = data["N"]
            self.total_dl       = data["total_dl"]
            self.k1             = data.get("k1", self.k1)
            self.b              = data.get("b",  self.b)
            logger.info(f"[BM25] Loaded index with {self.N} chunks from {path}")
            return True
        except Exception as exc:
            logger.error(f"[BM25] Failed to load index from {path}: {exc}")
            return False

    # ------------------------------------------------------------------
    # Private: writer thread
    # ------------------------------------------------------------------

    def _writer_loop(self) -> None:
        """
        Single consumer — serialises ALL writes to inverted_index.
        Never runs concurrently with another writer.
        """
        while True:
            try:
                cmd = self._write_q.get(timeout=30)
            except queue.Empty:
                continue

            kind = cmd[0]

            if kind == "add":
                _, chunks, save = cmd
                t0 = time.perf_counter()
                try:
                    self._apply_chunks(chunks)
                    elapsed_ms = (time.perf_counter() - t0) * 1000
                    logger.info(
                        f"[BM25] Added {len(chunks)} chunks "
                        f"(index={self.N} docs, apply={elapsed_ms:.1f}ms)"
                    )
                    if save:
                        t_save = time.perf_counter()
                        self._flush_and_save()
                        logger.info(f"[BM25] Save completed in {(time.perf_counter()-t_save)*1000:.0f}ms")
                except Exception as exc:
                    logger.error(f"[BM25] _apply_chunks failed: {exc}", exc_info=True)
                finally:
                    self._write_q.task_done()

            elif kind == "flush":
                _, done_event = cmd
                self._flush_and_save()
                done_event.set()
                self._write_q.task_done()

    def _apply_chunks(self, chunks: List[Dict[str, Any]]) -> None:
        """
        Mutate the index — ONLY called from _writer_loop().
        Requires _rlock to prevent dict resizing while search() iterates.
        """
        for chunk in chunks:
            text     = chunk.get("text", "")
            meta     = chunk.get("metadata", {})
            chunk_id = meta.get("chunk_id") or chunk.get("id")

            tokens  = _tokenize(text)
            doc_len = len(tokens)
            tf = Counter(tokens)

            with self._rlock:
                doc_idx = len(self.documents)
                self.documents.append({
                    "id":       chunk_id,
                    "length":   doc_len,
                    "company_symbol": meta.get("company_symbol", ""),
                    "active":   meta.get("active", True),
                })

                for token, count in tf.items():
                    self.df[token] = self.df.get(token, 0) + 1
                    if token not in self.inverted_index:
                        self.inverted_index[token] = array.array('I')
                    self.inverted_index[token].extend((doc_idx, count))

                self.N        += 1
                self.total_dl += doc_len

        # Signal readers to recompute IDF before next search
        with self._rlock:
            self._idf_dirty = True

    def _flush_and_save(self) -> None:
        """
        Recompute IDF (under _rlock) then pickle to disk.
        Called only from the writer thread.
        """
        with self._rlock:
            self._recompute_idf()
            self._idf_dirty = False
            # Snapshot under lock — fast shallow copies
            data = {
                "documents":      list(self.documents),
                "inverted_index": dict(self.inverted_index),
                "df":       dict(self.df),
                "idf":      dict(self.idf),
                "N":        self.N,
                "total_dl": self.total_dl,
                "k1":       self.k1,
                "b":        self.b,
            }
        # Pickle outside the lock — expensive, but no readers blocked
        self._write_to_disk(data)

    # ------------------------------------------------------------------
    # Private: internal search (called under _rlock held by search())
    # ------------------------------------------------------------------

    def _search_internal(
        self,
        query:          str,
        company_symbol: Optional[str],
        top_k:          int,
    ) -> List[Dict[str, Any]]:
        tokens  = _tokenize(query)
        scores: Dict[int, float] = {}
        avg_dl  = self.total_dl / self.N if self.N > 0 else 1.0

        for token in set(tokens):
            if token not in self.inverted_index:
                continue
            idf = self.idf.get(token, 0.0)
            arr = self.inverted_index[token]
            for i in range(0, len(arr), 2):
                doc_idx = arr[i]
                tf = arr[i+1]
                dl  = self.documents[doc_idx]["length"]
                num = tf * (self.k1 + 1)
                den = tf + self.k1 * (1 - self.b + self.b * dl / avg_dl)
                scores[doc_idx] = scores.get(doc_idx, 0.0) + idf * (num / den)

        results = []
        for doc_idx, score in scores.items():
            if score <= 0:
                continue
            doc  = self.documents[doc_idx]
            
            if company_symbol:
                doc_sym = doc.get("company_symbol", "").upper()
                if isinstance(company_symbol, list):
                    syms = [s.upper() for s in company_symbol if s]
                    if syms and doc_sym not in syms:
                        continue
                elif isinstance(company_symbol, dict) and "$in" in company_symbol:
                    syms = [s.upper() for s in (company_symbol["$in"] or []) if s]
                    if syms and doc_sym not in syms:
                        continue
                elif isinstance(company_symbol, str):
                    if doc_sym != company_symbol.upper():
                        continue

            if doc.get("active") is False:
                continue

            results.append({
                "id":          doc["id"],
                "score":       float(score),
                "source":      "sparse",
            })

        results.sort(key=lambda x: x["score"], reverse=True)
        top_results = results[:top_k]

        # Fetch missing text and metadata from Qdrant for top_k
        if top_results:
            try:
                from vector_store.neaps_qdrant_store import get_neaps_qdrant_store
                store = get_neaps_qdrant_store()
                qdrant_points = store.client.retrieve(
                    collection_name=store.collection_name,
                    ids=[r["id"] for r in top_results],
                    with_payload=True,
                )
                payload_map = {str(p.id): p.payload for p in qdrant_points}
                for r in top_results:
                    pld = payload_map.get(str(r["id"]), {})
                    r["text"] = pld.get("text", "")
                    r["metadata"] = pld
                    r["source_type"] = pld.get("source_type", "neaps_document")
            except Exception as exc:
                logger.error(f"[BM25] Failed to fetch payloads from Qdrant: {exc}")
                for r in top_results:
                    r["text"] = ""
                    r["metadata"] = {}
                    r["source_type"] = "neaps_document"

        return top_results

    # ------------------------------------------------------------------
    # Private: disk I/O
    # ------------------------------------------------------------------

    def _recompute_idf(self) -> None:
        """Recompute IDF dict from current df. Must be called under _rlock."""
        self.idf.clear()
        for token, freq in self.df.items():
            self.idf[token] = math.log(1 + (self.N - freq + 0.5) / (freq + 0.5))

    def _write_to_disk(self, data: dict, path: Path = None) -> None:
        """Atomic write: serialize to .tmp then rename."""
        path = path or _INDEX_FILE
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        try:
            with open(tmp, "wb") as f:
                pickle.dump(data, f, protocol=pickle.HIGHEST_PROTOCOL)
            tmp.replace(path)
            logger.info(f"[BM25] Index saved to {path} ({data['N']} docs).")
        except Exception as exc:
            logger.error(f"[BM25] Save failed: {exc}")


# ---------------------------------------------------------------------------
# Singleton factory
# ---------------------------------------------------------------------------
_index: Optional[LocalIncrementalBM25] = None
_index_lock = threading.Lock()


def get_bm25_index() -> LocalIncrementalBM25:
    """Return the global BM25 singleton, loading from disk on first access."""
    global _index
    if _index is None:
        with _index_lock:
            if _index is None:
                _index = LocalIncrementalBM25()
                _index.load()
    return _index
